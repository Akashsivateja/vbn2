<#
.SYNOPSIS
    Automated deployment script for Customer Billing Audit & SQL Analyst POC static web application.
.DESCRIPTION
    Creates/updates AWS CloudFormation stack (S3 bucket + CloudFront CDN) and
    uploads frontend files to the S3 bucket, invalidating CloudFront caches.
.PARAMETER StackName
    The name of the CloudFormation Stack. Defaults to "BillingAuditPOC".
.PARAMETER BucketName
    The globally unique S3 bucket name. Defaults to "billing-audit-poc-[RandomSuffix]".
.PARAMETER Region
    The AWS region to deploy infrastructure. Defaults to "us-east-1".
.EXAMPLE
    .\deploy-aws.ps1 -BucketName "my-billing-audit-agent-poc"
#>

param (
    [string]$StackName = "BillingAuditPOC",
    [string]$BucketName = "",
    [string]$Region = "us-east-1"
)

$ErrorActionPreference = "Stop"

# Clear Host Screen for output readability
Clear-Host

Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "    BILLING AUDIT AWS DEPLOYMENT RUNNER     " -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan

# 1. Generate unique bucket name if none provided
if ([string]::IsNullOrEmpty($BucketName)) {
    $random = Get-Random -Minimum 10000 -Maximum 99999
    $BucketName = "billing-audit-poc-$random"
    Write-Host "[*] No bucket name provided. Generated unique name: $BucketName" -ForegroundColor Yellow
}

# 2. Check for AWS CLI Installation
Write-Host "[*] Checking if AWS CLI is installed..." -ForegroundColor Gray
$awsPath = Get-Command aws -ErrorAction SilentlyContinue
if (-not $awsPath) {
    Write-Host "[ERROR] AWS CLI is not installed or not in System PATH. Please download and install it: https://aws.amazon.com/cli/" -ForegroundColor Red
    Exit 1
}
Write-Host "[✓] AWS CLI detected." -ForegroundColor Green

# 3. Check for valid AWS Credentials
Write-Host "[*] Validating AWS connection credentials..." -ForegroundColor Gray
try {
    $callerId = aws sts get-caller-identity --query "Arn" --output text 2>$null
    Write-Host "[✓] Authenticated as: $callerId" -ForegroundColor Green
} catch {
    Write-Host "[ERROR] Could not connect to AWS. Please ensure you have run 'aws configure' and credentials are valid." -ForegroundColor Red
    Exit 1
}

# 4. Deploying AWS CloudFormation Stack
Write-Host "`n[*] Deploying AWS CloudFormation stack: $StackName (Region: $Region)..." -ForegroundColor Gray
Write-Host "[*] This can take up to 2-3 minutes. Creating secure S3 bucket and CloudFront CDN..." -ForegroundColor Gray

$cfnParams = @(
    "cloudformation", "deploy",
    "--template-file", "aws-infra.yaml",
    "--stack-name", $StackName,
    "--parameter-overrides", "BucketName=$BucketName",
    "--region", $Region
)

# Execute CloudFormation deployment
$deployResult = & aws $cfnParams
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] CloudFormation deployment failed. Check AWS Console for errors." -ForegroundColor Red
    Exit 1
}
Write-Host "[✓] CloudFormation Infrastructure Stack successfully deployed." -ForegroundColor Green

# 5. Extracting Stack Output Values
Write-Host "`n[*] Querying Stack Outputs..." -ForegroundColor Gray
$outputs = aws cloudformation describe-stacks --stack-name $StackName --region $Region --query "Stacks[0].Outputs" --output json | ConvertFrom-Json

$s3BucketName = ($outputs | Where-Object { $_.OutputKey -eq "S3BucketName" }).OutputValue
$cloudFrontUrl = ($outputs | Where-Object { $_.OutputKey -eq "CloudFrontURL" }).OutputValue
$cfDistributionId = ($outputs | Where-Object { $_.OutputKey -eq "CloudFrontDistributionId" }).OutputValue

Write-Host "[✓] Target S3 Bucket: $s3BucketName" -ForegroundColor Green
Write-Host "[✓] CloudFront Distribution Domain: $cloudFrontUrl" -ForegroundColor Green
Write-Host "[✓] CloudFront Distribution ID: $cfDistributionId" -ForegroundColor Green

# 6. Upload static assets to S3
Write-Host "`n[*] Syncing local assets to target S3 bucket..." -ForegroundColor Gray
$syncParams = @(
    "s3", "sync", ".", "s3://$s3BucketName",
    "--exclude", "*.git*",
    "--exclude", "deploy-aws.ps1",
    "--exclude", "aws-infra.yaml"
)

& aws $syncParams
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] S3 Asset Upload failed." -ForegroundColor Red
    Exit 1
}
Write-Host "[✓] Assets synced to S3." -ForegroundColor Green

# 7. Invalidate CloudFront CDN Cache
Write-Host "`n[*] Creating CloudFront distribution invalidation to clear global CDN cache..." -ForegroundColor Gray
$invalidationId = aws cloudfront create-invalidation --distribution-id $cfDistributionId --paths "/*" --query "Invalidation.Id" --output text

if ($LASTEXITCODE -ne 0) {
    Write-Host "[WARNING] CloudFront cache invalidation failed. Changes might take up to 24 hours to propagate." -ForegroundColor Yellow
} else {
    Write-Host "[✓] CDN Cache Invalidation triggered. ID: $invalidationId" -ForegroundColor Green
}

# 8. Finished Deployment Banner
Write-Host "`n========================================================" -ForegroundColor Green
Write-Host "     DEPLOYMENT SUCCESSFUL!                             " -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Green
Write-Host " Your Billing Audit AI Agent POC is now live at:        " -ForegroundColor White
Write-Host " $cloudFrontUrl " -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Green
Write-Host "Share the URL above to showcase the Billing Audit POC." -ForegroundColor Gray
