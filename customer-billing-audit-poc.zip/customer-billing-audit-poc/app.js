// Customer Billing Audit & SQL Analyst Agentic AI POC
// Author: Antigravity AI Agent

document.addEventListener('DOMContentLoaded', () => {
    // 1. Initial UI Elements and State
    const agentInput = document.getElementById('agent-input');
    const agentSubmitBtn = document.getElementById('agent-submit-btn');
    const agentLogs = document.getElementById('agent-logs');
    const sqlEditor = document.getElementById('sql-editor');
    const runSqlBtn = document.getElementById('run-sql-btn');
    
    // Tab switching
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    // Status indicators
    const statusAgent = document.getElementById('status-agent');
    const statusDb = document.getElementById('status-db');

    let dbInitialized = false;
    let currentChart = null;

    // 2. Initialize AlaSQL Database and Seed Data
    function initDatabase() {
        try {
            // Drop existing tables just in case
            alasql('DROP TABLE IF EXISTS payments');
            alasql('DROP TABLE IF EXISTS invoices');
            alasql('DROP TABLE IF EXISTS subscriptions');
            alasql('DROP TABLE IF EXISTS customers');
            alasql('DROP TABLE IF EXISTS audit_logs');

            // Create Tables
            alasql('CREATE TABLE customers (id INT PRIMARY KEY, name STRING, email STRING, subscription_tier STRING, status STRING, created_at STRING, country STRING)');
            alasql('CREATE TABLE subscriptions (id INT PRIMARY KEY, customer_id INT, tier STRING, status STRING, price DECIMAL, started_at STRING, billing_cycle STRING)');
            alasql('CREATE TABLE invoices (id INT PRIMARY KEY, customer_id INT, amount DECIMAL, status STRING, created_at STRING, due_date STRING, subscription_id INT)');
            alasql('CREATE TABLE payments (id INT PRIMARY KEY, invoice_id INT, amount DECIMAL, status STRING, payment_method STRING, created_at STRING)');
            alasql('CREATE TABLE audit_logs (id INT INT_IDENTITY, event_type STRING, details STRING, created_at STRING)');

            // Seed Customers
            alasql('INSERT INTO customers VALUES (101, "Alice Vance", "alice.vance@example.com", "Premium", "Active", "2026-01-10", "US")');
            alasql('INSERT INTO customers VALUES (102, "Bob Miller", "bob.miller@example.com", "Pro", "Active", "2026-02-15", "CA")');
            alasql('INSERT INTO customers VALUES (103, "Charlie Song", "charlie.song@example.com", "Enterprise", "Active", "2026-03-01", "SG")');
            alasql('INSERT INTO customers VALUES (104, "Diana Prince", "diana.prince@example.com", "Pro", "Active", "2026-01-20", "US")');
            alasql('INSERT INTO customers VALUES (105, "Ethan Hunt", "ethan.hunt@example.com", "Premium", "Cancelled", "2026-02-01", "UK")');
            alasql('INSERT INTO customers VALUES (106, "Fiona Gallagher", "fiona.g@example.com", "Enterprise", "Active", "2026-04-12", "IE")');
            alasql('INSERT INTO customers values (107, "George Clark", "george.c@example.com", "Pro", "Active", "2026-05-01", "DE")');

            // Seed Subscriptions
            alasql('INSERT INTO subscriptions VALUES (201, 101, "Premium", "active", 99.00, "2026-01-10", "monthly")');
            alasql('INSERT INTO subscriptions VALUES (202, 102, "Pro", "active", 49.00, "2026-02-15", "monthly")');
            alasql('INSERT INTO subscriptions VALUES (203, 103, "Enterprise", "active", 199.00, "2026-03-01", "monthly")');
            alasql('INSERT INTO subscriptions VALUES (204, 104, "Pro", "active", 49.00, "2026-01-20", "monthly")');
            alasql('INSERT INTO subscriptions VALUES (205, 105, "Premium", "cancelled", 99.00, "2026-02-01", "monthly")');
            alasql('INSERT INTO subscriptions VALUES (206, 106, "Enterprise", "active", 199.00, "2026-04-12", "monthly")');
            alasql('INSERT INTO subscriptions VALUES (207, 107, "Pro", "active", 49.00, "2026-05-01", "monthly")');

            // Seed Invoices
            alasql('INSERT INTO invoices VALUES (301, 101, 99.00, "Paid", "2026-05-10 08:00:00", "2026-05-17", 201)');
            alasql('INSERT INTO invoices VALUES (302, 101, 99.00, "Paid", "2026-06-10 08:00:00", "2026-06-17", 201)');
            alasql('INSERT INTO invoices VALUES (303, 102, 49.00, "Paid", "2026-05-15 10:00:00", "2026-05-22", 202)');
            alasql('INSERT INTO invoices VALUES (304, 102, 49.00, "Paid", "2026-06-15 10:00:00", "2026-06-22", 202)');
            alasql('INSERT INTO invoices VALUES (305, 103, 199.00, "Paid", "2026-05-01 09:00:00", "2026-05-08", 203)');
            alasql('INSERT INTO invoices VALUES (306, 103, 199.00, "Paid", "2026-06-01 09:00:00", "2026-06-08", 203)');

            // Anomaly 1: Double Billing - customer 104 (Diana Prince) charged twice within 3 minutes in May
            alasql('INSERT INTO invoices VALUES (307, 104, 49.00, "Paid", "2026-05-20 09:00:00", "2026-05-27", 204)');
            alasql('INSERT INTO invoices VALUES (308, 104, 49.00, "Paid", "2026-05-20 09:02:15", "2026-05-27", 204)');
            alasql('INSERT INTO invoices VALUES (309, 104, 49.00, "Paid", "2026-06-20 09:00:00", "2026-06-27", 204)');

            // Anomaly 2: Pricing Mismatch - customer 106 (Fiona Gallagher). Subscription Enterprise ($199), but billed $299
            alasql('INSERT INTO invoices VALUES (310, 106, 299.00, "Paid", "2026-05-12 11:00:00", "2026-05-19", 206)');
            alasql('INSERT INTO invoices VALUES (311, 106, 299.00, "Paid", "2026-06-12 11:00:00", "2026-06-19", 206)');

            // Anomaly 3: Zombie Billing - customer 105 (Ethan Hunt). Subscription cancelled but invoiced in May and June
            alasql('INSERT INTO invoices VALUES (312, 105, 99.00, "Paid", "2026-05-01 09:00:00", "2026-05-08", 205)');
            alasql('INSERT INTO invoices VALUES (313, 105, 99.00, "Paid", "2026-06-01 09:00:00", "2026-06-08", 205)');

            // Anomaly 4: Revenue Leakage - customer 107 (George Clark). Subscription active, but unpaid invoices
            alasql('INSERT INTO invoices VALUES (314, 107, 49.00, "Open", "2026-05-01 09:00:00", "2026-05-08", 207)');
            alasql('INSERT INTO invoices VALUES (315, 107, 49.00, "Open", "2026-06-01 09:00:00", "2026-06-08", 207)');

            // Seed Payments
            alasql('INSERT INTO payments VALUES (401, 301, 99.00, "Succeeded", "Credit Card", "2026-05-10 08:05:00")');
            alasql('INSERT INTO payments VALUES (402, 302, 99.00, "Succeeded", "Credit Card", "2026-06-10 08:03:00")');
            alasql('INSERT INTO payments VALUES (403, 303, 49.00, "Succeeded", "PayPal", "2026-05-15 10:10:00")');
            alasql('INSERT INTO payments VALUES (404, 304, 49.00, "Succeeded", "PayPal", "2026-06-15 10:05:00")');
            alasql('INSERT INTO payments VALUES (405, 305, 199.00, "Succeeded", "Credit Card", "2026-05-01 09:05:00")');

            // Anomaly 5: Payment Refunded but Invoice is still marked Paid (Charlie Song, Invoice 306)
            alasql('INSERT INTO payments VALUES (406, 306, 199.00, "Refunded", "Credit Card", "2026-06-05 14:20:00")');

            // Payments for Double Billing
            alasql('INSERT INTO payments VALUES (407, 307, 49.00, "Succeeded", "Apple Pay", "2026-05-20 09:01:00")');
            alasql('INSERT INTO payments VALUES (408, 308, 49.00, "Succeeded", "Apple Pay", "2026-05-20 09:03:00")');
            alasql('INSERT INTO payments VALUES (409, 309, 49.00, "Succeeded", "Apple Pay", "2026-06-20 09:02:00")');

            // Payments for Pricing Mismatch
            alasql('INSERT INTO payments VALUES (410, 310, 299.00, "Succeeded", "Credit Card", "2026-05-12 11:05:00")');
            alasql('INSERT INTO payments VALUES (411, 311, 299.00, "Succeeded", "Credit Card", "2026-06-12 11:03:00")');

            // Payments for Zombie Billing
            alasql('INSERT INTO payments VALUES (412, 312, 99.00, "Succeeded", "Credit Card", "2026-05-01 09:04:00")');
            alasql('INSERT INTO payments VALUES (413, 313, 99.00, "Succeeded", "Credit Card", "2026-06-01 09:05:00")');

            // Failed payments for customer 107
            alasql('INSERT INTO payments VALUES (414, 314, 49.00, "Failed", "Credit Card", "2026-05-02 09:00:00")');
            alasql('INSERT INTO payments VALUES (415, 314, 49.00, "Failed", "Credit Card", "2026-05-05 10:15:00")');
            alasql('INSERT INTO payments VALUES (416, 315, 49.00, "Failed", "Credit Card", "2026-06-02 09:00:00")');

            // Seed Audit Logs
            alasql('INSERT INTO audit_logs VALUES (1, "DB_INIT", "Database tables seeded with billing transactions & logs.", "2026-06-22 19:00:00")');
            
            dbInitialized = true;
            statusDb.innerHTML = '<span class="indicator db-active pulse"></span> SQLite (AlaSQL) Active';
            
            // Build Schema Explorer Items
            buildSchemaExplorer();
            
            // Initialize Dashboard Counters & Overview Charts
            runOverallMetrics();
            
            console.log("Database initialized successfully!");
        } catch (e) {
            console.error("Failed to initialize database:", e);
            statusDb.innerHTML = '<span class="indicator badge-error"></span> Database Error';
        }
    }

    // 3. Populate Schema Explorer Details
    function buildSchemaExplorer() {
        const schemas = {
            customers: [
                { name: 'id', type: 'INT', key: 'PK' },
                { name: 'name', type: 'STRING', key: '' },
                { name: 'email', type: 'STRING', key: '' },
                { name: 'subscription_tier', type: 'STRING', key: '' },
                { name: 'status', type: 'STRING', key: '' },
                { name: 'created_at', type: 'STRING', key: '' },
                { name: 'country', type: 'STRING', key: '' }
            ],
            subscriptions: [
                { name: 'id', type: 'INT', key: 'PK' },
                { name: 'customer_id', type: 'INT', key: 'FK' },
                { name: 'tier', type: 'STRING', key: '' },
                { name: 'status', type: 'STRING', key: '' },
                { name: 'price', type: 'DECIMAL', key: '' },
                { name: 'started_at', type: 'STRING', key: '' },
                { name: 'billing_cycle', type: 'STRING', key: '' }
            ],
            invoices: [
                { name: 'id', type: 'INT', key: 'PK' },
                { name: 'customer_id', type: 'INT', key: 'FK' },
                { name: 'amount', type: 'DECIMAL', key: '' },
                { name: 'status', type: 'STRING', key: '' },
                { name: 'created_at', type: 'STRING', key: '' },
                { name: 'due_date', type: 'STRING', key: '' },
                { name: 'subscription_id', type: 'INT', key: 'FK' }
            ],
            payments: [
                { name: 'id', type: 'INT', key: 'PK' },
                { name: 'invoice_id', type: 'INT', key: 'FK' },
                { name: 'amount', type: 'DECIMAL', key: '' },
                { name: 'status', type: 'STRING', key: '' },
                { name: 'payment_method', type: 'STRING', key: '' },
                { name: 'created_at', type: 'STRING', key: '' }
            ],
            audit_logs: [
                { name: 'id', type: 'INT', key: 'PK (AUTO)' },
                { name: 'event_type', type: 'STRING', key: '' },
                { name: 'details', type: 'STRING', key: '' },
                { name: 'created_at', type: 'STRING', key: '' }
            ]
        };

        const schemaList = document.querySelector('.schema-list');
        schemaList.innerHTML = ''; // Clear previous

        Object.keys(schemas).forEach(tableName => {
            const tableDiv = document.createElement('div');
            tableDiv.className = 'schema-table';
            
            const headerDiv = document.createElement('div');
            headerDiv.className = 'schema-header';
            headerDiv.innerHTML = `<span>📁 ${tableName}</span> <span>▼</span>`;
            
            const colsDiv = document.createElement('div');
            colsDiv.className = 'schema-cols';
            
            schemas[tableName].forEach(col => {
                const keyBadge = col.key ? `<span class="col-key">${col.key}</span>` : '';
                colsDiv.innerHTML += `
                    <div class="schema-col-item">
                        <span class="col-name">${col.name}${keyBadge}</span>
                        <span class="col-type">${col.type}</span>
                    </div>
                `;
            });
            
            headerDiv.addEventListener('click', () => {
                colsDiv.classList.toggle('open');
                headerDiv.querySelector('span:last-child').textContent = colsDiv.classList.contains('open') ? '▲' : '▼';
            });
            
            tableDiv.appendChild(headerDiv);
            tableDiv.appendChild(colsDiv);
            schemaList.appendChild(tableDiv);
        });
    }

    // 4. Tab switching logic
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const tabId = btn.getAttribute('data-tab');
            
            tabBtns.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            
            btn.classList.add('active');
            document.getElementById(tabId).classList.add('active');
        });
    });

    // 5. Preset Audits Data and Agents Plans
    const auditPresets = {
        double_billing: {
            title: "Double Billing Detection",
            description: "Locate customers billed multiple times in the same day for matching amounts.",
            query: `SELECT \n  i1.customer_id, \n  c.name AS customer_name, \n  i1.id AS invoice_id_1, \n  i2.id AS invoice_id_2, \n  i1.amount AS billed_amount, \n  i1.created_at AS invoice_1_time, \n  i2.created_at AS invoice_2_time\nFROM invoices i1\nJOIN invoices i2 ON i1.customer_id = i2.customer_id \n  AND i1.amount = i2.amount \n  AND i1.id < i2.id \n  AND SUBSTRING(i1.created_at, 1, 10) = SUBSTRING(i2.created_at, 1, 10)\nJOIN customers c ON i1.customer_id = c.id`,
            steps: [
                { type: 'think', text: "Scan 'invoices' table to evaluate double-billing records." },
                { type: 'plan', text: "Compare individual invoice timestamps for matching customer IDs and charge amounts within a 24-hour window." },
                { type: 'act', text: "Execute self-join query mapping duplicate invoice rows..." },
                { type: 'sql', text: "SELECT \n  i1.customer_id, \n  c.name AS customer_name, \n  i1.id AS invoice_id_1, \n  i2.id AS invoice_id_2, \n  i1.amount AS billed_amount, \n  i1.created_at AS invoice_1_time, \n  i2.created_at AS invoice_2_time\nFROM invoices i1\nJOIN invoices i2 ON i1.customer_id = i2.customer_id \n  AND i1.amount = i2.amount \n  AND i1.id < i2.id \n  AND SUBSTRING(i1.created_at, 1, 10) = SUBSTRING(i2.created_at, 1, 10)\nJOIN customers c ON i1.customer_id = c.id" },
                { type: 'review', text: "Analysis: Detected 1 billing anomaly for customer Diana Prince (ID: 104) on 2026-05-20. Duplicate invoice IDs: 307 and 308 (Amount: $49.00). Double charge has been paid." },
                { type: 'report', text: "Result found: 1 distinct double billing event. Total leak/error impact: $49.00. Recommend refunding invoice 308." }
            ],
            chartConfig: {
                type: 'bar',
                data: {
                    labels: ['Diana Prince (ID 104)'],
                    datasets: [
                        { label: 'Invoice 1 (307)', data: [49.00], backgroundColor: '#6366f1' },
                        { label: 'Invoice 2 (308) - Double Charge', data: [49.00], backgroundColor: '#f43f5e' }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { labels: { color: '#e5e7eb' } }
                    },
                    scales: {
                        y: { ticks: { color: '#9ca3af' }, grid: { color: 'rgba(255,255,255,0.05)' } },
                        x: { ticks: { color: '#9ca3af' }, grid: { color: 'rgba(255,255,255,0.05)' } }
                    }
                }
            }
        },
        price_mismatch: {
            title: "Subscription Price Audit",
            description: "Find mismatch between subscription tier price and actual invoiced amount.",
            query: `SELECT \n  c.id AS customer_id, \n  c.name AS customer_name, \n  s.tier AS subscription_tier, \n  s.price AS contract_price, \n  i.id AS invoice_id, \n  i.amount AS invoiced_amount, \n  (i.amount - s.price) AS variance\nFROM invoices i\nJOIN subscriptions s ON i.subscription_id = s.id\nJOIN customers c ON i.customer_id = c.id\nWHERE i.amount != s.price AND i.status != 'Void'`,
            steps: [
                { type: 'think', text: "Cross-audit contract tiers and actual charges. Looking for pricing mismatch." },
                { type: 'plan', text: "Perform inner join between subscriptions table and invoices table to inspect if contracted subscription tier pricing matches the billed amount." },
                { type: 'act', text: "Compile check conditions mapping amount discrepancies..." },
                { type: 'sql', text: "SELECT \n  c.id AS customer_id, \n  c.name AS customer_name, \n  s.tier AS subscription_tier, \n  s.price AS contract_price, \n  i.id AS invoice_id, \n  i.amount AS invoiced_amount, \n  (i.amount - s.price) AS variance\nFROM invoices i\nJOIN subscriptions s ON i.subscription_id = s.id\nJOIN customers c ON i.customer_id = c.id\nWHERE i.amount != s.price AND i.status != 'Void'" },
                { type: 'review', text: "Analysis: Discovered active pricing mismatch. Customer Fiona Gallagher (ID: 106) has Enterprise tier contracted at $199.00 but was invoiced at $299.00 on both Invoice 310 (May) and Invoice 311 (June). Positive variance: +$100.00 per invoice." },
                { type: 'report', text: "Results found: 2 mismatched invoices. Total variance impact: +$200.00. Customers overcharged due to billing catalog mismatch. Recommend updating pricing settings." }
            ],
            chartConfig: {
                type: 'bar',
                data: {
                    labels: ['Invoice 310 (May)', 'Invoice 311 (June)'],
                    datasets: [
                        { label: 'Contract Price', data: [199, 199], backgroundColor: '#10b981' },
                        { label: 'Billed Amount', data: [299, 299], backgroundColor: '#f43f5e' }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { labels: { color: '#e5e7eb' } }
                    },
                    scales: {
                        y: { ticks: { color: '#9ca3af' }, grid: { color: 'rgba(255,255,255,0.05)' } },
                        x: { ticks: { color: '#9ca3af' }, grid: { color: 'rgba(255,255,255,0.05)' } }
                    }
                }
            }
        },
        zombie_billing: {
            title: "Zombie Subscription Billing",
            description: "Locate billing invoices issued to subscriptions that have been cancelled.",
            query: `SELECT \n  c.id AS customer_id, \n  c.name AS customer_name, \n  s.status AS subscription_status, \n  i.id AS invoice_id, \n  i.amount AS invoice_amount, \n  i.created_at AS invoice_date\nFROM invoices i\nJOIN subscriptions s ON i.subscription_id = s.id\nJOIN customers c ON i.customer_id = c.id\nWHERE s.status = 'cancelled' OR s.status = 'inactive'`,
            steps: [
                { type: 'think', text: "Scan subscription accounts checking for active billing on inactive statuses." },
                { type: 'plan', text: "Search for invoices created after subscriptions have transitioned to 'cancelled' or 'inactive'." },
                { type: 'act', text: "Query table mapping invoices to cancelled subscriptions..." },
                { type: 'sql', text: "SELECT \n  c.id AS customer_id, \n  c.name AS customer_name, \n  s.status AS subscription_status, \n  i.id AS invoice_id, \n  i.amount AS invoice_amount, \n  i.created_at AS invoice_date\nFROM invoices i\nJOIN subscriptions s ON i.subscription_id = s.id\nJOIN customers c ON i.customer_id = c.id\nWHERE s.status = 'cancelled' OR s.status = 'inactive'" },
                { type: 'review', text: "Analysis: Identified critical compliance anomaly. Customer Ethan Hunt (ID: 105) cancelled his Premium tier subscription in February (status: cancelled). However, Invoice 312 ($99.00 in May) and Invoice 313 ($99.00 in June) were generated and charged." },
                { type: 'report', text: "Results found: 2 billing events on cancelled account. Total wrongful charges: $198.00. Immediate cancellation of recurring invoices is required to prevent customer litigation." }
            ],
            chartConfig: {
                type: 'bar',
                data: {
                    labels: ['Ethan Hunt (ID 105)'],
                    datasets: [
                        { label: 'Billed Amount after Cancellation', data: [198.00], backgroundColor: '#f43f5e' }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { labels: { color: '#e5e7eb' } }
                    },
                    scales: {
                        y: { ticks: { color: '#9ca3af' }, grid: { color: 'rgba(255,255,255,0.05)' } },
                        x: { ticks: { color: '#9ca3af' }, grid: { color: 'rgba(255,255,255,0.05)' } }
                    }
                }
            }
        },
        revenue_leakage: {
            title: "Revenue Leakage Analysis",
            description: "Find active users with repeated failed payments who are still receiving service.",
            query: `SELECT \n  c.id AS customer_id, \n  c.name AS customer_name, \n  s.tier AS subscription_tier, \n  COUNT(DISTINCT i.id) AS open_invoices, \n  SUM(i.amount) AS unpaid_leakage_amount\nFROM invoices i\nJOIN subscriptions s ON i.subscription_id = s.id\nJOIN customers c ON i.customer_id = c.id\nWHERE i.status = 'Open' AND s.status = 'active'\nGROUP BY c.id, c.name, s.tier`,
            steps: [
                { type: 'think', text: "Analyze active subscription statuses against failed payment histories to locate revenue leaks." },
                { type: 'plan', text: "Identify customers with outstanding open invoices and active subscriptions, then verify payment attempts." },
                { type: 'act', text: "Aggregating open invoices and sum value of unpaid subscriptions..." },
                { type: 'sql', text: "SELECT \n  c.id AS customer_id, \n  c.name AS customer_name, \n  s.tier AS subscription_tier, \n  COUNT(DISTINCT i.id) AS open_invoices, \n  SUM(i.amount) AS unpaid_leakage_amount\nFROM invoices i\nJOIN subscriptions s ON i.subscription_id = s.id\nJOIN customers c ON i.customer_id = c.id\nWHERE i.status = 'Open' AND s.status = 'active'\nGROUP BY c.id, c.name, s.tier" },
                { type: 'review', text: "Analysis: Detected revenue leakage. Customer George Clark (ID: 107) has an active Pro subscription ($49/mo) but has 2 open invoices (Invoice 314 & Invoice 315). Credit card payment logs show 3 failed payment attempts (id 414, 415, 416). Customer accounts were not locked." },
                { type: 'report', text: "Results found: 1 customer account leaking revenue. Total leakage amount: $98.00. Recommend immediate suspension of services until payments succeed." }
            ],
            chartConfig: {
                type: 'doughnut',
                data: {
                    labels: ['Collected Revenue', 'Leaked/Unpaid Revenue'],
                    datasets: [{
                        data: [1392.00, 98.00],
                        backgroundColor: ['#10b981', '#f43f5e'],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { labels: { color: '#e5e7eb' }, position: 'bottom' }
                    }
                }
            }
        },
        refund_mismatch: {
            title: "Refund Status Discrepancy",
            description: "Detect transactions where payment was refunded but the invoice is still marked Paid.",
            query: `SELECT \n  c.id AS customer_id, \n  c.name AS customer_name, \n  i.id AS invoice_id, \n  i.amount AS invoice_amount, \n  i.status AS invoice_status, \n  p.id AS payment_id, \n  p.status AS payment_status\nFROM payments p\nJOIN invoices i ON p.invoice_id = i.id\nJOIN customers c ON i.customer_id = c.id\nWHERE p.status = 'Refunded' AND i.status = 'Paid'`,
            steps: [
                { type: 'think', text: "Scan matching pairs of payments and invoices to check audit compliance." },
                { type: 'plan', text: "Query payments with status 'Refunded' and verify if the parent invoice state was correctly updated." },
                { type: 'act', text: "Run relational inner joins mapping payment states to invoice states..." },
                { type: 'sql', text: "SELECT \n  c.id AS customer_id, \n  c.name AS customer_name, \n  i.id AS invoice_id, \n  i.amount AS invoice_amount, \n  i.status AS invoice_status, \n  p.id AS payment_id, \n  p.status AS payment_status\nFROM payments p\nJOIN invoices i ON p.invoice_id = i.id\nJOIN customers c ON i.customer_id = c.id\nWHERE p.status = 'Refunded' AND i.status = 'Paid'" },
                { type: 'review', text: "Analysis: Found double ledger error. Customer Charlie Song (ID: 103) has payment 406 for invoice 306 ($199.00) marked as 'Refunded', but invoice status remains 'Paid' instead of 'Refunded' or 'Void'." },
                { type: 'report', text: "Result found: 1 status sync error. Financial ledger mismatch. Total discrepant amount: $199.00. Recommend syncing the invoice state to prevent service provision for a refunded account." }
            ],
            chartConfig: {
                type: 'bar',
                data: {
                    labels: ['Charlie Song (ID 103)'],
                    datasets: [
                        { label: 'Refunded Payment Value', data: [199.00], backgroundColor: '#f59e0b' },
                        { label: 'Invoice Ledger State (Paid)', data: [199.00], backgroundColor: '#10b981' }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { labels: { color: '#e5e7eb' } }
                    },
                    scales: {
                        y: { ticks: { color: '#9ca3af' }, grid: { color: 'rgba(255,255,255,0.05)' } },
                        x: { ticks: { color: '#9ca3af' }, grid: { color: 'rgba(255,255,255,0.05)' } }
                    }
                }
            }
        }
    };

    // Preset Buttons Event Listeners
    document.querySelectorAll('.preset-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const auditKey = btn.getAttribute('data-audit');
            const selectedAudit = auditPresets[auditKey];
            
            document.querySelectorAll('.preset-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            if (selectedAudit) {
                // Populate SQL editor with query
                sqlEditor.value = selectedAudit.query;
                // Run the Agent simulation
                runAgentAudit(selectedAudit);
            }
        });
    });

    // 6. Running Metrics Overview Counters (Top Widget)
    function runOverallMetrics() {
        try {
            // Unpaid/leakage amount calculation
            const unpaid = alasql("SELECT SUM(amount) AS leak FROM invoices WHERE status = 'Open'");
            const totalInvoiced = alasql("SELECT SUM(amount) AS total_invoiced FROM invoices");
            const invoicesCount = alasql("SELECT COUNT(*) AS cnt FROM invoices");
            
            // Anomalies calculation
            const doubleBilledCount = alasql(`
                SELECT COUNT(DISTINCT i1.id) AS cnt 
                FROM invoices i1
                JOIN invoices i2 ON i1.customer_id = i2.customer_id 
                  AND i1.amount = i2.amount 
                  AND i1.id < i2.id 
                  AND SUBSTRING(i1.created_at, 1, 10) = SUBSTRING(i2.created_at, 1, 10)
            `)[0].cnt;

            const mismatchCount = alasql(`
                SELECT COUNT(*) AS cnt 
                FROM invoices i
                JOIN subscriptions s ON i.subscription_id = s.id
                WHERE i.amount != s.price AND i.status != 'Void'
            `)[0].cnt;

            const zombieCount = alasql(`
                SELECT COUNT(*) AS cnt 
                FROM invoices i
                JOIN subscriptions s ON i.subscription_id = s.id
                WHERE s.status = 'cancelled' OR s.status = 'inactive'
            `)[0].cnt;

            const refundDiscrepancy = alasql(`
                SELECT COUNT(*) AS cnt 
                FROM payments p
                JOIN invoices i ON p.invoice_id = i.id
                WHERE p.status = 'Refunded' AND i.status = 'Paid'
            `)[0].cnt;

            const leakVal = unpaid[0].leak || 0;
            const invoicedVal = totalInvoiced[0].total_invoiced || 0;
            const totalAnomalies = (doubleBilledCount / 2) + mismatchCount + zombieCount + refundDiscrepancy;

            document.getElementById('metric-leakage').textContent = `$${leakVal.toFixed(2)}`;
            document.getElementById('metric-anomalies').textContent = totalAnomalies;
            document.getElementById('metric-invoiced').textContent = `$${invoicedVal.toFixed(2)}`;
            document.getElementById('metric-volume').textContent = invoicesCount[0].cnt;

            // Generate initial overview chart
            renderOverviewChart(invoicedVal, leakVal, doubleBilledCount * 49 / 2, mismatchCount * 100);
            
            // Build findings list
            buildFindingsWidget(doubleBilledCount > 0, mismatchCount, zombieCount, leakVal, refundDiscrepancy);

        } catch (e) {
            console.error("Error generating metrics:", e);
        }
    }

    function buildFindingsWidget(doubleBilled, mismatchCount, zombieCount, leakage, refundDiscrepancy) {
        const findingsList = document.querySelector('.findings-list');
        findingsList.innerHTML = '';

        if (doubleBilled) {
            findingsList.appendChild(createFindingItem(
                "CRITICAL: Double Billing Anomaly",
                "High Impact",
                "-$49.00",
                "Customer Diana Prince (ID 104) double charged within 3 mins.",
                "INVOICES: 307 & 308"
            ));
        }
        if (mismatchCount > 0) {
            findingsList.appendChild(createFindingItem(
                "WARNING: Contract Price Mismatch",
                "Medium Impact",
                "+$200.00",
                `Customer Fiona Gallagher (ID 106) overcharged $100/mo over 2 cycles.`,
                "INVOICES: 310 & 311"
            ));
        }
        if (zombieCount > 0) {
            findingsList.appendChild(createFindingItem(
                "COMPLIANCE: Inactive Account Invoicing",
                "High Impact",
                "-$198.00",
                `Ethan Hunt (ID 105) billed twice after subscription cancellation.`,
                "INVOICES: 312 & 313"
            ));
        }
        if (leakage > 0) {
            findingsList.appendChild(createFindingItem(
                "REVENUE: Open Invoice Leakage",
                "High Risk",
                `$${leakage.toFixed(2)}`,
                "Active sub George Clark (ID 107) has failed payments, account active.",
                "INVOICES: 314 & 315"
            ));
        }
        if (refundDiscrepancy > 0) {
            findingsList.appendChild(createFindingItem(
                "LEDGER: Refund Status Sync Mismatch",
                "Medium Impact",
                "Discrepancy: $199.00",
                "Charlie Song (ID 103) refunded, invoice ledger state remains Paid.",
                "INVOICE: 306"
            ));
        }
    }

    function createFindingItem(title, risk, impact, desc, ref) {
        const div = document.createElement('div');
        div.className = 'finding-item';
        div.innerHTML = `
            <div class="finding-header">
                <span class="finding-title">${title}</span>
                <span class="badge ${risk === 'High Impact' || risk === 'High Risk' ? 'badge-error' : 'badge-warning'}">${risk}</span>
            </div>
            <div class="finding-desc">${desc}</div>
            <div class="finding-meta">
                <span>REF: ${ref}</span>
                <span class="finding-impact">${impact}</span>
            </div>
        `;
        return div;
    }

    function renderOverviewChart(invoiced, leakage, doubleCharged, pricingVariance) {
        const ctx = document.getElementById('auditChart').getContext('2d');
        if (currentChart) {
            currentChart.destroy();
        }

        currentChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Total Invoiced', 'Direct Revenue Leak', 'Wrongful Double Billing', 'Pricing Mismatch Variance'],
                datasets: [{
                    label: 'Audit Dollars ($)',
                    data: [invoiced, leakage, doubleCharged, pricingVariance],
                    backgroundColor: [
                        'rgba(16, 185, 129, 0.65)',
                        'rgba(244, 63, 94, 0.65)',
                        'rgba(245, 158, 11, 0.65)',
                        'rgba(99, 102, 241, 0.65)'
                    ],
                    borderColor: [
                        '#10b981',
                        '#f43f5e',
                        '#f59e0b',
                        '#6366f1'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        ticks: { color: '#9ca3af' },
                        grid: { color: 'rgba(255,255,255,0.05)' }
                    },
                    x: {
                        ticks: { color: '#9ca3af' },
                        grid: { color: 'rgba(255,255,255,0.05)' }
                    }
                }
            }
        });
    }

    // 7. Simulated Agentic AI Loop
    function runAgentAudit(audit) {
        // Pulse agent active indicator
        statusAgent.innerHTML = '<span class="indicator agent-active pulse"></span> Agent Auditing...';
        agentLogs.innerHTML = ''; // Clear terminal logs
        
        let stepIdx = 0;

        function printNextStep() {
            if (stepIdx < audit.steps.length) {
                const step = audit.steps[stepIdx];
                const logRow = document.createElement('div');
                logRow.className = `log-row ${step.type}`;
                
                let icon = '';
                if (step.type === 'think') icon = '🧠 [THINK] ';
                else if (step.type === 'plan') icon = '📝 [PLAN] ';
                else if (step.type === 'act') icon = '⚡ [ACT] ';
                else if (step.type === 'sql') icon = '🔍 [RUN SQL] ';
                else if (step.type === 'review') icon = '🔎 [REVIEW] ';
                else if (step.type === 'report') icon = '📊 [REPORT] ';

                if (step.type === 'sql') {
                    logRow.innerHTML = `${icon}<pre class="log-row sql">${step.text}</pre>`;
                } else {
                    logRow.textContent = `${icon}${step.text}`;
                }

                agentLogs.appendChild(logRow);
                agentLogs.scrollTop = agentLogs.scrollHeight;
                
                stepIdx++;
                
                // Set dynamic delays for agent thoughts to feel natural
                let delay = 900;
                if (step.type === 'sql') delay = 1200;
                if (step.type === 'review') delay = 1500;
                
                setTimeout(printNextStep, delay);
            } else {
                // Done executing simulation steps
                statusAgent.innerHTML = '<span class="indicator agent-active"></span> Agent Idle';
                
                // Execute SQL Query to populate the tables and display
                executeSqlQuery(audit.query);
                
                // Render specific Audit Presets Chart
                if (audit.chartConfig) {
                    renderAuditChart(audit.chartConfig);
                }
            }
        }

        printNextStep();
    }

    // Render chart specifically for an audit Preset
    function renderAuditChart(chartConfig) {
        const ctx = document.getElementById('auditChart').getContext('2d');
        if (currentChart) {
            currentChart.destroy();
        }
        currentChart = new Chart(ctx, chartConfig);
    }

    // 8. SQL execution engine & results rendering
    function executeSqlQuery(sql) {
        try {
            const results = alasql(sql);
            renderResultsTable(results);
            
            // Switch tabs to "SQL Results"
            tabBtns.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            
            const resultsTab = document.querySelector('[data-tab="tab-results"]');
            resultsTab.classList.add('active');
            document.getElementById('tab-results').classList.add('active');

            // Log event in audit logs table
            alasql(`INSERT INTO audit_logs (event_type, details, created_at) VALUES ("SQL_QUERY", "Executed custom SQL statement: ${sql.slice(0, 50).replace(/"/g, "'")}...", "2026-06-22 19:02:00")`);
            
        } catch (error) {
            console.error("SQL Syntax Error:", error);
            
            const logRow = document.createElement('div');
            logRow.className = 'log-row error';
            logRow.textContent = `❌ [SQL ERROR]: ${error.message}`;
            agentLogs.appendChild(logRow);
            agentLogs.scrollTop = agentLogs.scrollHeight;
            
            // Render error state inside results tab
            const resultsDiv = document.getElementById('tab-results');
            resultsDiv.innerHTML = `
                <div class="no-data-placeholder">
                    <div class="no-data-icon">⚠️</div>
                    <div style="color: var(--accent-rose); font-weight:600;">SQL Syntax Execution Failed</div>
                    <div style="font-size: 0.75rem; font-family: var(--font-mono); margin-top:0.5rem; background:rgba(0,0,0,0.2); padding:0.5rem; border-radius:4px; border:1px solid rgba(255,255,255,0.05);">${error.message}</div>
                </div>
            `;
        }
    }

    function renderResultsTable(results) {
        const resultsDiv = document.getElementById('tab-results');
        
        if (!results || results.length === 0) {
            resultsDiv.innerHTML = `
                <div class="no-data-placeholder">
                    <div class="no-data-icon">🔍</div>
                    <div>Query executed successfully.</div>
                    <div style="font-size: 0.75rem; color: var(--text-muted);">Returned 0 records.</div>
                </div>
            `;
            return;
        }

        const headers = Object.keys(results[0]);
        
        let tableHtml = `
            <div class="data-table-container">
                <table class="data-table">
                    <thead>
                        <tr>
                            ${headers.map(h => `<th>${h}</th>`).join('')}
                        </tr>
                    </thead>
                    <tbody>
        `;

        results.forEach(row => {
            // Detect if row is an anomaly to highlight it
            let isAnomaly = false;
            if (row.invoice_id_2 || row.variance !== undefined || row.subscription_status === 'cancelled' || row.unpaid_leakage_amount !== undefined || row.payment_status === 'Refunded') {
                isAnomaly = true;
            }

            tableHtml += `<tr class="${isAnomaly ? 'anomaly-row' : ''}">`;
            headers.forEach(h => {
                let cellVal = row[h];
                if (cellVal === null || cellVal === undefined) {
                    cellVal = 'NULL';
                }
                
                // Beautiful status badging
                if (h === 'status' || h === 'invoice_status' || h === 'payment_status' || h === 'subscription_status') {
                    let badgeClass = 'badge-info';
                    if (['Paid', 'Succeeded', 'Active', 'active'].includes(cellVal)) {
                        badgeClass = 'badge-success';
                    } else if (['Failed', 'Cancelled', 'cancelled', 'Open'].includes(cellVal)) {
                        badgeClass = 'badge-error';
                    } else if (['Refunded', 'inactive'].includes(cellVal)) {
                        badgeClass = 'badge-warning';
                    }
                    cellVal = `<span class="badge ${badgeClass}">${cellVal}</span>`;
                }

                tableHtml += `<td>${cellVal}</td>`;
            });
            tableHtml += `</tr>`;
        });

        tableHtml += `
                    </tbody>
                </table>
            </div>
        `;

        resultsDiv.innerHTML = tableHtml;
    }

    // 9. Natural Language Processor / Custom Input Agent Router
    function processUserNaturalLanguage(query) {
        if (!query.trim()) return;

        const cleanQuery = query.toLowerCase();
        let matchedPreset = null;

        // Simple Keyword Routing Router
        if (cleanQuery.includes('double') || cleanQuery.includes('duplicate') || cleanQuery.includes('twice')) {
            matchedPreset = 'double_billing';
        } else if (cleanQuery.includes('mismatch') || cleanQuery.includes('price') || cleanQuery.includes('contract') || cleanQuery.includes('pricing') || cleanQuery.includes('incorrect charge')) {
            matchedPreset = 'price_mismatch';
        } else if (cleanQuery.includes('zombie') || cleanQuery.includes('cancelled') || cleanQuery.includes('inactive') || cleanQuery.includes('cancel')) {
            matchedPreset = 'zombie_billing';
        } else if (cleanQuery.includes('leak') || cleanQuery.includes('leakage') || cleanQuery.includes('failed') || cleanQuery.includes('unpaid')) {
            matchedPreset = 'revenue_leakage';
        } else if (cleanQuery.includes('refund') || cleanQuery.includes('ledger') || cleanQuery.includes('void')) {
            matchedPreset = 'refund_mismatch';
        }

        if (matchedPreset) {
            // Find the preset element and active it visually
            document.querySelectorAll('.preset-btn').forEach(b => {
                if (b.getAttribute('data-audit') === matchedPreset) {
                    b.click();
                }
            });
        } else {
            // Try to evaluate if it starts with SELECT and execute it directly
            if (cleanQuery.trim().startsWith('select ') || cleanQuery.trim().startsWith('show ')) {
                statusAgent.innerHTML = '<span class="indicator agent-active pulse"></span> Executing direct query...';
                agentLogs.innerHTML = '';
                
                const logRow1 = document.createElement('div');
                logRow1.className = 'log-row think';
                logRow1.textContent = '🧠 [THINK] Direct SQL Input identified. Evaluating query safety and correctness...';
                agentLogs.appendChild(logRow1);

                setTimeout(() => {
                    const logRow2 = document.createElement('div');
                    logRow2.className = 'log-row act';
                    logRow2.textContent = '⚡ [ACT] Compiling SQL query...';
                    agentLogs.appendChild(logRow2);
                    
                    const logRow3 = document.createElement('div');
                    logRow3.className = 'log-row sql';
                    logRow3.innerHTML = `<pre class="log-row sql">${query}</pre>`;
                    agentLogs.appendChild(logRow3);
                    
                    executeSqlQuery(query);
                    statusAgent.innerHTML = '<span class="indicator agent-active"></span> Agent Idle';
                }, 800);
            } else {
                // Return generic agent explanation
                statusAgent.innerHTML = '<span class="indicator agent-active pulse"></span> Thinking...';
                agentLogs.innerHTML = '';
                
                const logRow1 = document.createElement('div');
                logRow1.className = 'log-row think';
                logRow1.textContent = `🧠 [THINK] Received query: "${query}"`;
                agentLogs.appendChild(logRow1);
                
                setTimeout(() => {
                    const logRow2 = document.createElement('div');
                    logRow2.className = 'log-row review';
                    logRow2.textContent = `🔎 [REVIEW] Could not automatically map keywords. I can help you compile queries on the schema. Try asking about: 'double billing', 'price mismatch', 'cancelled accounts', or 'revenue leakage'.`;
                    agentLogs.appendChild(logRow2);
                    
                    statusAgent.innerHTML = '<span class="indicator agent-active"></span> Agent Idle';
                }, 900);
            }
        }
    }

    // Submit handler
    agentSubmitBtn.addEventListener('click', () => {
        const query = agentInput.value;
        processUserNaturalLanguage(query);
        agentInput.value = '';
    });

    agentInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const query = agentInput.value;
            processUserNaturalLanguage(query);
            agentInput.value = '';
        }
    });

    // Run custom SQL editor button
    runSqlBtn.addEventListener('click', () => {
        const customSql = sqlEditor.value;
        if (!customSql.trim()) return;

        statusAgent.innerHTML = '<span class="indicator agent-active pulse"></span> Running custom SQL...';
        agentLogs.innerHTML = '';
        
        const logRow = document.createElement('div');
        logRow.className = 'log-row act';
        logRow.textContent = '⚡ [PLAYGROUND] Executing custom SQL editor transaction...';
        agentLogs.appendChild(logRow);
        
        executeSqlQuery(customSql);
        statusAgent.innerHTML = '<span class="indicator agent-active"></span> Agent Idle';
    });

    // 10. Run Database initialization
    initDatabase();
});
